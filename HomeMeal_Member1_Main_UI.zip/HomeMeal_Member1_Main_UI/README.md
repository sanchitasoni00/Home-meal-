# HomeMeal — Member 1 Main UI

Main Streamlit UI implementing Student → Location → Nearby Cooks → Menu → Meal Plan → Subscription → Order Confirmation, plus a basic Home Cook dashboard.

Run with `streamlit run app.py`.
